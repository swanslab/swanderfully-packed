# packed-data
 An archive to track my datapack practice.

## Shoutout to [misode](https://misode.github.io/) and [r/MinecraftCommands](https://www.reddit.com/r/MinecraftCommands/) for providing very handy resources for development.
